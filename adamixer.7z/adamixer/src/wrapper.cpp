#include <string>
#include "llama.h"

void* llama_build_vector(const std::string& text, int add_bos) {
    return NULL;
}